package services;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.RoomDao;


public class RoomServiceImpl implements RoomServices {
	
	 @Autowired
		private RoomDao RoomDaoImpl;
		@PostConstruct
		public void display() {
			System.out.println("RoomDaoImpl created"); 
		}
		public RoomDao getRoomDaoImpl() {
			return RoomDaoImpl;
		}
		public void setRoomDaoImpl(RoomDao roomDaoImpl) {
			RoomDaoImpl = roomDaoImpl;
		}
		
		

}
