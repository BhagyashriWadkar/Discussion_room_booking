package services;

import org.springframework.web.servlet.ModelAndView;

public interface RoomServices {
	
}
