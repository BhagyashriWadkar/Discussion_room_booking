package dao;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

public class RoomDaoImpl implements RoomDao {

	

}
