package dao;

import org.springframework.web.servlet.ModelAndView;

public interface RoomDao {

}
