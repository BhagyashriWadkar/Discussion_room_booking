package controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import services.RoomServices;
;

@Controller
public class Room_controller {
	String message="InsideController";
	@Autowired
	RoomServices RoomService;
	@PostConstruct
	public void display() {
		System.out.println("RoomService created");
	}
	public RoomServices getRoomService() {
		return RoomService;
	}
	public void setRoomService(RoomServices roomService) {
		RoomService = roomService;
	}





	@RequestMapping("/First")
	public ModelAndView showMessage() {
		System.out.println("in controller");
 
		ModelAndView mv = new ModelAndView("First");
		mv.addObject("message", message);
		return mv;
	}
}
