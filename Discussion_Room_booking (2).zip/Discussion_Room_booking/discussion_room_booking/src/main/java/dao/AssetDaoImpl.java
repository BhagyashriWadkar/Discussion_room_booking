package dao;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import java.sql.ResultSet;    
import java.sql.SQLException;    
import java.util.List;    
import org.springframework.jdbc.core.BeanPropertyRowMapper;    
import org.springframework.jdbc.core.JdbcTemplate;    
import org.springframework.jdbc.core.RowMapper;    
import beans.Assets;
public class AssetDaoImpl implements AssetDao {
JdbcTemplate template;
                 
	public void setTemplate(JdbcTemplate template) {    
	    this.template = template;    
	}    

	public List<Assets> getAssets() {
		System.out.println("inside getAssets");
		Assets a=new Assets();    
		return template.query("select * from assets",new RowMapper<Assets>(){ 
			public Assets mapRow(ResultSet rs, int row) throws SQLException 
			{
				
					
		            a.setAsset_id(rs.getInt(1));    
		            a.setAsset_name(rs.getString(2));
		            a.setAsset_count(rs.getInt(3)); 
		            a.setAsset_status(rs.getBoolean(4));    
		            System.out.println(a);
		            return a; 
				}
				 
			
			
	    });    
	}    

}
