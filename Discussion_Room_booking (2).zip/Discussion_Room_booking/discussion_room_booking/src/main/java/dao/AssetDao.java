package dao;

import java.util.List;
import beans.Assets;


public interface AssetDao {
	public List<Assets> getAssets();
}
