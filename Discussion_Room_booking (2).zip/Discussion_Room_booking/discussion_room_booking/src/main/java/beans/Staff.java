package beans;

public class Staff {
	
	String Name;
	int Staff_id;
	String Password;
	String Email;
	long Contact_no;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getStaff_id() {
		return Staff_id;
	}
	public void setStaff_id(int staff_id) {
		Staff_id = staff_id;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public long getContact_no() {
		return Contact_no;
	}
	public void setContact_no(long contact_no) {
		Contact_no = contact_no;
	}
	
	

}
