package controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;



import beans.Assets;
import services.AssetServices;


@Controller
public class controller {
	String message="InsideController";
	@Autowired
	AssetServices assetServices;
	@PostConstruct
	public void display() {
		System.out.println("AssetService created");
	}
	public AssetServices getAssetService() {
		return assetServices;
	}
	public void setAssetService(AssetServices assetService) {
		this.assetServices = assetService;
	}
	
	/*@RequestMapping("/display")
	public ModelAndView showAssets()
	{
		System.out.println("in display");
		List<Assets> list=assetServices.;    
	    m.addAttribute("list",list);  
	    return "viewemp";    
	}
	*/

	

	@RequestMapping("/display")
	public ModelAndView display(HttpServletRequest request, HttpServletResponse response) {
	

		System.out.println("get Assets in controller is called successfully");				
		ModelAndView  modelView = new ModelAndView("display");
		List<Assets> Assets = null;
		try {
			Assets = assetServices.getAssets();
 		}catch (Exception e) {
 			System.out.println("Exception in assetServices.getAssets()");
		}				
		modelView.addObject("Assets", Assets);

		return modelView;
	}
	

	/*@RequestMapping("/First")
	public ModelAndView showMessage() {
		System.out.println("in controller");
 
		//ModelAndView mv = new ModelAndView("First");
		//mv.addObject("message", message);
		return mv;
	}*/
}
