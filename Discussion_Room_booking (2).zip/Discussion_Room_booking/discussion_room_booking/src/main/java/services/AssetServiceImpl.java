package services;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import java.util.List;
import beans.Assets;
import dao.AssetDao;



public class AssetServiceImpl implements AssetServices {
	
	 @Autowired
		AssetDao daoImpl;
		@PostConstruct
		public void display() {
			System.out.println("AssetDaoImpl created"); 
		}
		public AssetDao getAssetDaoImpl() {
			return daoImpl;
		}
		public void setAssetDaoImpl(AssetDao assetDaoImpl) {
			this.daoImpl = assetDaoImpl;
		}
		
		    	   

		
		public List<Assets> getAssets() {
			/*List<Assets> list=AssetDaoImpl.getAssets();    
	        m.addAttribute("list",list);  */
			System.out.println("Inside AssetServiceImpl");
			List<Assets> list=daoImpl.getAssets(); 
			System.out.println(list);
	        return list;    
		}    

}
