package services;

import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import beans.Assets;

public interface AssetServices {
	 public List<Assets> getAssets();
}
